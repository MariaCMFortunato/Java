/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exemplo28.classecliente;

import InterfaceGrafica.JFrameMenu;

/**
 *
 * @author Maria11
 */
public class Exemplo28ClasseCliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrameMenu jfm1 = new JFrameMenu();
        jfm1.setVisible(true);
    }
    
}
