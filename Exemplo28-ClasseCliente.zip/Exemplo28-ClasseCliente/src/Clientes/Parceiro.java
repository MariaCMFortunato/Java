/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clientes;

/**
 *
 * @author Maria11
 */
public class Parceiro  {
    protected String Nome;
    
    public Parceiro()
    {
        Nome = "";
    }

    public String getNome() 
    {
        return Nome;
    }

    public void setNome(String n) 
    {
        Nome = n;
    }
    
    
}
